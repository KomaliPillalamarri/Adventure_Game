import java.util.Scanner;
public class adventure {
    static String currentRoom = "Entrance";
    static String[] inventory = new String[10]; 
    static int inventoryCount = 0; 
    static int playerHealth = 100;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Adventure Game!");
        while (true) {
            if (playerHealth <= 0) {
                System.out.println("Game Over. You have no health left.");
                break;
            }
            if (currentRoom.equals("Treasure Room") && hasItem("Treasure")) {
                System.out.println("You Win! Congratulations on collecting the treasure!");
                break;
            }
            describeRoom();
            System.out.print("What do you want to do? ");
            String command = scanner.nextLine().toLowerCase();
            if (command.startsWith("go ")) {
                navigate(command.substring(3));
            } else if (command.equals("check inventory")) {
                checkInventory();
            } else if (command.equals("talk")) {
                interactWithNPC();
            } else if (command.equals("attack")) {
                combat();
            } else if (command.equals("run")) {
                System.out.println("You retreat to a safer location.");
                currentRoom = "Entrance";
            } else {
                System.out.println("Invalid command.");
            }
        }
        scanner.close();
    }
    static void describeRoom() {
        switch (currentRoom) {
            case "Entrance":
                System.out.println("\nYou are in Entrance");
                System.out.println("You are at the entrance of a mysterious world. Exits: north.");
                break;
            case "Forest":
                System.out.println("\nYou are in Forest");
                System.out.println("You are in a dense forest. You see something shiny in the distance. Exits: south, east.");
                break;
            case "Dungeon":
                System.out.println("\nYou are in Dungeon");
                System.out.println("A dark and creepy dungeon. You hear growls nearby. Exits: west, east.");
                break;
            case "Treasure Room":
                System.out.println("\nYou are in Treasure Room");
                System.out.println("A golden treasure lies here. Exits: west.");
                break;
        }
    }
    static void navigate(String direction) {
        if (currentRoom.equals("Entrance") && direction.equals("north")) {
            currentRoom = "Forest";
            System.out.println("You move north.");
        } else if (currentRoom.equals("Forest")) {
            if (direction.equals("south")) {
                currentRoom = "Entrance";
                System.out.println("You move south.");
            } else if (direction.equals("east")) {
                currentRoom = "Dungeon";
                System.out.println("You move east.");
            } else {
                System.out.println("You can't go that way.");
            }
        } else if (currentRoom.equals("Dungeon")) {
            if (direction.equals("west")) {
                currentRoom = "Forest";
                System.out.println("You move west.");
            } else if (direction.equals("east")) {
                currentRoom = "Treasure Room";
                System.out.println("You move east.");
            } else {
                System.out.println("You can't go that way.");
            }
        } else if (currentRoom.equals("Treasure Room") && direction.equals("west")) {
            currentRoom = "Dungeon";
            System.out.println("You move west.");
        } else {
            System.out.println("You can't go that way.");
        }
    }
    static void checkInventory() {
        System.out.print("Inventory: ");
        if (inventoryCount == 0) {
            System.out.println("Empty");
        } else {
            for (int i = 0; i < inventoryCount; i++) {
                System.out.print(inventory[i] + (i < inventoryCount - 1 ? ", " : ""));
            }
            System.out.println();
        }
    }
    static void interactWithNPC() {
        if (currentRoom.equals("Forest")) {
            System.out.println("An old man gives you a hint: 'Beware of the dungeon.'");
        } else if (currentRoom.equals("Treasure Room")) {
            if (!hasItem("Treasure")) {
                System.out.println("You find the Treasure!");
                addItem("Treasure");
            } else {
                System.out.println("The room is empty now.");
            }
        } else {
            System.out.println("There's no one to talk to here.");
        }
    }
    static void combat() {
        if (currentRoom.equals("Dungeon")) {
            System.out.println("An enemy appears!");
            while (playerHealth > 0) {
                int damage = (int) (Math.random() * 10) + 1; 
                System.out.println("The enemy attacks you for " + damage + " damage.");
                playerHealth -= damage;
                if (playerHealth > 0) {
                    System.out.println("You attack back and defeat the enemy!");
                    return;
                }
            }
        } else {
            System.out.println("There's nothing to fight here.");
        }
    }
    static boolean hasItem(String item) {
        for (int i = 0; i < inventoryCount; i++) {
            if (inventory[i].equals(item)) {
                return true;
            }
        }
        return false;
    }
    static void addItem(String item) {
        if (inventoryCount < inventory.length) {
            inventory[inventoryCount++] = item;
        } else {
            System.out.println("Inventory full! Can't carry more items.");
        }
    }
}
